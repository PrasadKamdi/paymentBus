package io.pk.contract;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Created by 166141 on 22/08/2017.
 */
@CrossOrigin
@RestController
@RequestMapping("/pk")
public class Controller {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private IContract contract;

    public Controller(IContract iContract) {
        this.contract = iContract;
    }


    @PostMapping
    public ResponseEntity<Pojo> create(@RequestBody Pojo entry) {

        logger.debug("Create Method");
        Pojo createdTimeEntry = contract.create(entry);

        return new ResponseEntity<>(createdTimeEntry, HttpStatus.CREATED);
    }

    /**
     * Usage - http://localhost:8080/pk/1
     * @param id
     * @return
     */
    @GetMapping("{id}")
    public ResponseEntity<Pojo> read(@PathVariable int id) {
        Pojo obj = contract.find(id);
        if (obj != null) {
            return new ResponseEntity<>(obj, HttpStatus.OK);
        } else {
            obj = new Pojo();
            obj.setId(id);
            obj.setName("No user found with ID :" + id);
            //return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            return new ResponseEntity<>(obj, HttpStatus.I_AM_A_TEAPOT);
            // return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    /**
     * Usage - http://localhost:8080/pk
     * @return
     */
    @GetMapping
    public ResponseEntity<List<Pojo>> list() {
        return new ResponseEntity<>(contract.list(), HttpStatus.OK);
    }

    @PutMapping("{id}")
    public ResponseEntity<Pojo> update(@PathVariable int id, @RequestBody Pojo obj) {
        Pojo updatedTimeEntry = contract.update(id, obj);
        if (updatedTimeEntry != null) {
            return new ResponseEntity<>(updatedTimeEntry, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    @DeleteMapping("{id}")
    public ResponseEntity<Pojo> delete(@PathVariable int id) {
        contract.delete(id);

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
