package io.pk.contract;

import java.util.List;

/**
 * Created by 166141 on 22/08/2017.
 */
public interface IContract {

    Pojo create(Pojo obj);
    Pojo find(int id);
    List<Pojo> list();
    Pojo update(int id, Pojo obj);
    void delete(int id);
}
