package io.pk.contract

import java.io.Serializable

class Pojo : Serializable {
    var id: Int = 0
    var name: String? = null
    var date: String? = null
    var payName: String? = null
}