package io.pk.contract;

import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by 166141 on 29/08/2017.
 */

@RestController
public class HomeController {

    @GetMapping("/")
    public String sayHello(HttpServletRequest request) {

        String hylink =request.getRequestURL().toString()+"pk";
        String retVal="<!DOCTYPE html>\n" +
                "<html>\n" +
                "<body>\n" +
                "\n" +
                "<p><a href='"+hylink+"'>Usage Link</a></p>\n" +
                "\n" +
                "</body>\n" +
                "</html>\n";

        return retVal;

        // return "I am UP ; Usage "+ request.getRequestURL().toString()+ "pk";


    }
}
