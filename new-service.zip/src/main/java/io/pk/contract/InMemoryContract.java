package io.pk.contract;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by 166141 on 22/08/2017.
 */
public class InMemoryContract implements IContract {

    private HashMap<Integer, Pojo> entries = new HashMap<>();
    @Override
    public Pojo create(Pojo obj) {
        obj.setId(entries.size() + 1);
        entries.put(obj.getId(), obj);
        return obj;
    }

    @Override
    public Pojo find(int id) {
        return entries.get(id);
    }

    @Override
    public List<Pojo> list() {
        return new ArrayList<>(entries.values());
    }

    @Override
    public Pojo update(int id, Pojo obj) {
        entries.replace(id, obj);
        obj.setId(id);
        return obj;
    }

    @Override
    public void delete(int id) {
        entries.remove(id);
    }

}
